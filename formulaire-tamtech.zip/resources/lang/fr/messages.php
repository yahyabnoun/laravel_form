<?php

return [
    'E-Mail Address' => 'Me encanta programar.',
    "If you’re having trouble clicking the \":actionText\" button, copy and paste the URL below\n into your web browser:" => "Si vous ne parvenez pas à cliquer sur le bouton \":actionText\", copiez et collez l'URL ci-dessous\n",
];
