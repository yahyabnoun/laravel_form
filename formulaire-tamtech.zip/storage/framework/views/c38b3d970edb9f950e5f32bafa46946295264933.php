<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Resultats Conferences - TamTech</title>
    <link href="<?php echo e(asset('image/TAMTECH-02.png')); ?>" rel="icon">
    <link href="<?php echo e(asset('image/TAMTECH-02.png')); ?>" rel="apple-touch-icon">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1>Resultats</h1>
        <table class="table table-bordered mb-5">
            <thead>
                <tr class="table-primary">
                    <th scope="col">#</th>
                    <th scope="col">Full Name</th>
                    <th scope="col">Email Address</th>
                    <th scope="col">Phone Number</th>
                    <th scope="col">Company</th>
                    <th scope="col">Conference Access</th>
                    <th scope="col">Date Inscription</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $resultats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($data->id); ?></th>
                    <td><?php echo e($data->fullname); ?></td>
                    <td><?php echo e($data->email); ?></td>
                    <td><?php echo e($data->phone); ?></td>
                    <td><?php echo e($data->company); ?></td>
                    <td><?php echo e($data->type); ?></td>
                    <td><?php echo e($data->created_at); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        
        <div class="d-flex justify-content-center">
            <?php echo $resultats->links(); ?>

        </div>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\formulaire-tamtech\resources\views/resultat/indexConference.blade.php ENDPATH**/ ?>