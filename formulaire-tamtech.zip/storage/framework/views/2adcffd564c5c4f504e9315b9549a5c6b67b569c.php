<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Resultats - TamTech</title>
    <link href="<?php echo e(asset('image/TAMTECH-02.png')); ?>" rel="icon">
    <link href="<?php echo e(asset('image/TAMTECH-02.png')); ?>" rel="apple-touch-icon">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1>Resultats</h1>
        <table class="table table-bordered mb-5">
            <thead>
                <tr class="table-primary">
                    <th scope="col">#</th>
                    <th scope="col">Nom Complet</th>
                    <th scope="col">Email</th>
                    <th scope="col">Téléphone</th>
                    <th scope="col">Activité</th>
                    <th scope="col">Niveau</th>
                    <th scope="col">Langue</th>
                    <th scope="col">Date Inscription</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $resultat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($data->id); ?></th>
                    <td><?php echo e($data->fullname); ?></td>
                    <td><?php echo e($data->email); ?></td>
                    <td><?php echo e($data->phone); ?></td>
                    <td><?php echo e($data->activity); ?></td>
                    <td><?php echo e($data->niveau); ?></td>
                    <td><?php echo e($data->langue); ?></td>
                    <td><?php echo e($data->created_at); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        
        <div class="d-flex justify-content-center">
            <?php echo $resultat->links(); ?>

        </div>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\formulaire-tamtech\resources\views/resultat/index.blade.php ENDPATH**/ ?>